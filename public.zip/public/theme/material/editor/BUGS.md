#Bugs

> 说明：删除线表示已经解决。

####IE8

- ~~不能加载；~~
- flowChart（流程图）、sequenceDiagram（序列图）不支持IE8；
- ~~不支持Markdown转HTML页面解析预览；~~

####IE8 & IE9 & IE10

- KaTeX会出现解析错误，但不影响程序运行；

####Sea.js

- ~~Raphael.js无法加载；~~

####Require.js

- ~~CodeMirror编辑器的代码无法高亮；~~
- ~~sequenceDiagram不支持: `Uncaught TypeError: Cannot call method 'isArray' of undefined.`~~
